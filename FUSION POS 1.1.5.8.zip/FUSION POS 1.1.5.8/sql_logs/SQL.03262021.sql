 INSERT INTO `pos-grand_total_monitor_logs` ( store_code, pos_terminal, business_date, old_gt, new_gt, running_gt, discounts ) VALUES ( 'KFC901', 2, '2021-03-26 00:00:00', 363912.84, 363912.84, 363912.84, 1355.79 ); -- 2:31:00 PM 
 INSERT INTO `pos-transaction_cash_monitor`( store_code, post_type_code, action, amount, pos_terminal, employee_number, manager_employee_number, business_date, transaction_time, shift_number) VALUES ( 'KFC901', 'IC', 'C', 1500.00, 2, 4005555, 4001111, '2021-03-26', '2021-03-26 14:31:03', 1 ) ; -- 2:31:03 PM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 1616038051.437 AND store_code='KFC901'; -- 2:31:08 PM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 161615165867 AND store_code='KFC901'; -- 2:31:08 PM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 161640737667 AND store_code='KFC901'; -- 2:31:08 PM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 161640745067 AND store_code='KFC901'; -- 2:31:09 PM 
UPDATE `pos-business_date` SET standalone_sync_status=0, transactional_sync_status=0 WHERE store_code='KFC901' AND pos_terminal=2; -- 3:24:56 PM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 161717928899 AND store_code='KFC901'; -- 4:34:12 PM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 161775938703 AND store_code='KFC901'; -- 9:36:45 AM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 1616037444.36 AND store_code='KFC901'; -- 10:38:54 AM 
 UPDATE `pos-transaction_delivery_headers` SET printed = true WHERE delivery_transaction_number = 1616037444.36 AND store_code='KFC901'; -- 10:39:35 AM 
